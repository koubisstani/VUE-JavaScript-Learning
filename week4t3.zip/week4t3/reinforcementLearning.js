let canvas = document.getElementById('mazeCanvas');
let ctx = canvas.getContext('2d');
let stateSize = 50;  // Size of each state grid
let actions = ['up', 'down', 'left', 'right'];  // Executable actions

let startState = { x: 0, y: 50 };  // Entrance location
let goalState = { x: 0, y: 450 };  // exit position

// Define the initial direction of the cube, assuming that it initially moves to the right.
let currentDirection = 'right';

function drawMaze() {
    ctx.fillStyle = "#555555";

    // external wall
    ctx.fillRect(0, 0, 800, 50);  // Top facade
    ctx.fillRect(0, 500, 800, 150);  // Bottom facade
    ctx.fillRect(0, 0, 50, 800);  // Left facade
    ctx.fillRect(750, 0, 50, 800);  // Right facade

    // Design of internal walls based on the labyrinth diagram provided
    ctx.fillRect(0, 100, 650, 50); 
    ctx.fillRect(650, 100, 50, 200);
    ctx.fillRect(0, 150, 650, 150); 
    ctx.fillRect(100, 200, 600, 450); 

    // enter and exit
    ctx.clearRect(0, 50, 50, 50);  // enter
    ctx.clearRect(0, 450, 50, 50);  // exit
    ctx.clearRect(100, 300, 650, 50);
}

function isWall(state) {
    const walls = [
        { x: 0, y: 0, width: 800, height: 50 },  // Top facade
        { x: 0, y: 500, width: 800, height: 150 },  // Bottom facade
        { x: 0, y: 0, width: 50, height: 800 },  // Left facade
        { x: 750, y: 0, width: 50, height: 800 },  // Right facade
        { x: 0, y: 100, width: 650, height: 50 }, 
        { x: 650, y: 100, width: 50, height: 200 },
        { x: 0, y: 150, width: 650, height: 150 }, 
        { x: 100, y: 200, width: 600, height: 450 }, 
    ];

    for (let wall of walls) {
        if (state.x >= wall.x && state.x < wall.x + wall.width &&
            state.y >= wall.y && state.y < wall.y + wall.height) {
            return true;  // The current state is inside the wall.
        }
    }
    return false;  // It's not touching the wall.
}

function getNextState(state, direction) {
    let nextState = { ...state };
    
    // Move in the current direction
    if (direction === 'up') nextState.y -= stateSize;
    if (direction === 'down') nextState.y += stateSize;
    if (direction === 'left') nextState.x -= stateSize;
    if (direction === 'right') nextState.x += stateSize;

    // Check if it touches the wall, if it does, return to the current state and don't move.
    if (isWall(nextState)) {
        return state;
    }
    return nextState;
}

function drawRobot(x, y) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawMaze();

    ctx.fillStyle = 'purple';
    ctx.fillRect(x, y, stateSize, stateSize);
}

function chooseDirection(state) {
    // Determine if it is possible to continue in the current direction
    let nextState = getNextState(state, currentDirection);
    
    // If the current direction can be continued, return to the current direction
    if (nextState.x !== state.x || nextState.y !== state.y) {
        return currentDirection;
    }

    // If you hit a wall in the current direction, try another direction.
    const newDirections = actions.filter(dir => dir !== currentDirection);  // Avoiding regression
    for (let dir of newDirections) {
        let potentialState = getNextState(state, dir);
        if (potentialState.x !== state.x || potentialState.y !== state.y) {
            currentDirection = dir;  // Update direction
            return dir;
        }
    }

    // If all directions fail to advance, stay put
    return currentDirection;
}

function startTraining() {
    let state = { ...startState };
    let steps = 0;

    function step() {
        if (state.x === goalState.x && state.y === goalState.y) {
            console.log("Reached the goal!");
            return;  // The trolley reaches the end of the line.
        }

        steps++;
        let direction = chooseDirection(state);
        state = getNextState(state, direction);

        drawRobot(state.x, state.y);

        if (steps <= 1000) {
            setTimeout(step, 200);  // One step every 200 milliseconds
        } else {
            console.log("Training stopped due to too many steps.");
        }
    }

    step();
}

window.onload = () => {
    drawMaze();
    document.getElementById('trainButton').addEventListener('click', startTraining);
}
