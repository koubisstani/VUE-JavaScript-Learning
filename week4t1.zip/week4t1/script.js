let canvas = document.getElementById('carCanvas');
let ctx = canvas.getContext('2d');

let x = canvas.width / 2;
let y = canvas.height / 2;
let dx = 2;
let dy = 0;
let radius = 20;
let isRunning = false;
let animationId = null;

// Drawing a cart (circle and two lines as wheels)
function drawCar() {
  ctx.clearRect(0, 0, canvas.width, canvas.height); // Clearing the canvas

  // Drawing the body (round)
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fillStyle = 'blue';
  ctx.fill();
  ctx.stroke();

  // Drawing wheels
  ctx.lineWidth = 10;
  ctx.strokeStyle = 'black';
  ctx.beginPath();
  ctx.moveTo(x - 25, y - 10);
  ctx.lineTo(x - 25, y + 10);
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(x + 25, y - 10);
  ctx.lineTo(x + 25, y + 10);
  ctx.stroke();
}

// Update trolley position
function updateCarPosition() {
  x += dx;
  y += dy;

  // Detecting boundary collisions
  if (x + radius > canvas.width || x - radius < 0) {
    dx = -dx; // reverse motion
  }
  if (y + radius > canvas.height || y - radius < 0) {
    dy = -dy; // reverse motion
  }

  drawCar(); // Redrawing the cart
  animationId = requestAnimationFrame(updateCarPosition); // cyclic animation
}

// Start/Stop button click event
document.getElementById('startStopButton').addEventListener('click', () => {
  if (isRunning) {
    cancelAnimationFrame(animationId); // Stop animation
    document.getElementById('startStopButton').textContent = 'Start';
  } else {
    updateCarPosition(); // startup animation
    document.getElementById('startStopButton').textContent = 'Stop';
  }
  isRunning = !isRunning;
});

// Turn Button Click Event
document.getElementById('turnButton').addEventListener('click', () => {
  let temp = dx;
  dx = dy;
  dy = -temp; // turn
});

drawCar(); // Initial drawing
